from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.chains import RetrievalQA
from langchain.llms import OpenAI

def load_pdf_text(file):
    loader = PyPDFLoader(file)
    pages = loader.load()
    text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
    return text_splitter.split_documents(pages)

def create_vector_store(docs):
    embeddings = OpenAIEmbeddings()
    return FAISS.from_documents(docs, embeddings)

def answer_query(vectordb, query):
    qa_chain = RetrievalQA.from_chain_type(llm=OpenAI(), retriever=vectordb.as_retriever())
    return qa_chain.run(query)